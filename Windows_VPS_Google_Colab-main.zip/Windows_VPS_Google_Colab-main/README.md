# Windows_7_VPS_12Hours
```bash
!wget -O khanhnguyen9872.sh https://raw.githubusercontent.com/KhanhNguyen9872/Windows_VPS_Google_Colab/main/khanhnguyen9872.sh
!bash khanhnguyen9872.sh
```
