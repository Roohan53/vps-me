#!/bin/sh
java -jar /usr/bin/microemulator.jar
